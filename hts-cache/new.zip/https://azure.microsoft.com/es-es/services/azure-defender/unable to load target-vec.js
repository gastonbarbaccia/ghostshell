

<html lang="es">

<head>
    <meta name="robots" content="noindex">
    <title>404 - P&#225;gina no encontrada</title>
    <link href="/dest/bundles/core.css?v=cvt-c2f9efa2c04a26e449a85927f1233294e19f6390772809594275a90edd86d1d9" rel="stylesheet" />
    <style>
        body {
            background-color: #1a1a1a;
        }

        .tutorial-icon svg use {
            stroke: #00abec;
        }
    </style>
</head>

<body>
    <div class="section section--color05 hero-404">
        <div class="row column">
            <h1 class="text-super">
                <strong>404</strong>
                P&#225;gina no encontrada
            </h1>
        </div>
        <div class="row row-size2">
            <div class="column">
                <p class="text-heading2">No encontramos la p&#225;gina que busca.</p>
                <p>Puede que no haya escrito la direcci&#243;n correctamente o quiz&#225;s haya usado un v&#237;nculo obsoleto.</p>
                <p>Pruebe a buscar:</p>
            </div>
        </div>
        <div class="row row-size2">
            <div class="column">
                <form id="search-404" method="get" action="/es-es/search/" aria-label="Formulario de b&#250;squeda">
                    <div class="wa-text wa-textSearch wa-text-light">
                        <input name="q" class="text-input filter" placeholder="Search" />
                        <button type="reset" class="clear" aria-label="Borrar">&times;</button>
                        <button class="search-button" aria-label="Search"></button>
                    </div>
                </form>
            </div>
        </div>
        <div class="row row-size2 text-center">
            <div class="column">
                <img alt="" role="presentation" src="/images/page/not-found/cityscape.png?v=c2f9efa2c04a26e449a85927f1233294e19f6390772809594275a90edd86d1d9" />
            </div>
        </div>
    </div>

    <section class="section" aria-label="V&#237;nculos &#250;tiles">
        <div class="row column">
            <h2>V&#237;nculos &#250;tiles</h2>
        </div>
        <div class="row row-size3">
            <div class="column medium-3">
                <ul class="wa-iconList">
                    <li>
                        <a href="/es-es/services/">
                            <span class="icon tutorial-icon"><svg aria-hidden="true" role="presentation" data-slug-id="tutorial" xmlns="http://www.w3.org/2000/svg" viewBox="-2 -1 35 35">
    <path fill="#FFFFFF" d="M2.7,11.6l3.5-4.5C6.3,7,6.4,6.8,6.3,6.7L6.3,6.5L5.6,5.9C5.5,5.8,5.4,5.8,5.3,5.8L5,5.8L2.6,8.9L1.4,7.6 C1.3,7.5,1.2,7.5,1,7.5l-0.2,0L0.2,8.1C0,8.3-0.1,8.6,0.1,8.8L2.7,11.6z"/>
    <path fill="#FFFFFF" d="M5.6,13.2c-0.1-0.1-0.2-0.1-0.3-0.1L5,13.2l-2.4,3.1L1.4,15c-0.1-0.1-0.2-0.2-0.4-0.2l-0.2,0l-0.6,0.6 c-0.2,0.2-0.2,0.5,0,0.7L2.7,19l3.5-4.5c0.1-0.1,0.1-0.2,0.1-0.4l-0.1-0.3L5.6,13.2z"/>
    <path fill="#FFFFFF" d="M5.6,20.5c-0.1-0.1-0.2-0.1-0.3-0.1L5,20.4l-2.4,3.1l-1.2-1.3c-0.1-0.1-0.2-0.2-0.4-0.2l-0.2,0l-0.6,0.6 c-0.2,0.2-0.2,0.5,0,0.7l2.6,2.8l3.5-4.5c0.1-0.1,0.1-0.2,0.1-0.4L6.3,21L5.6,20.5z"/>
    <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M28,8.8H9.7c-0.6,0-1.2,0.5-1.2,1.1c0,0.6,0.5,1.1,1.2,1.1H28 c0.6,0,1.2-0.5,1.2-1.1C29.2,9.3,28.7,8.8,28,8.8z"/>
    <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M30.8,15.3H9.7c-0.6,0-1.2,0.5-1.2,1.1c0,0.6,0.5,1.1,1.2,1.1h21.1 c0.6,0,1.2-0.5,1.2-1.1C32,15.8,31.5,15.3,30.8,15.3z"/>
    <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M25.6,21.9H9.7c-0.6,0-1.2,0.5-1.2,1.1c0,0.6,0.5,1.1,1.2,1.1h15.9 c0.6,0,1.2-0.5,1.2-1.1C26.8,22.3,26.2,21.9,25.6,21.9z"/>
</svg></span>
                            <span class="title">Productos</span>
                            <span class="summary">Examinar una creciente lista de servicios integrados de Azure</span>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="column medium-3 medium-offset-1">
                <ul class="wa-iconList">
                    <li>
                        <a href="/es-es/documentation/">
                            <span class="icon"><svg aria-hidden="true" role="presentation" data-slug-id="book" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">
    <path fill="#59B4D9" d="M25.256,0H3v30h22.256C26.215,30,27,29.297,27,28.438V1.563C27,0.704,26.215,0,25.256,0z M21,11.416H9V7.688 h12V11.416z"/>
    <polygon fill="#5E5E5E" points="23.377,10.313 20.215,8.438 17.052,10.313 17.052,0 23.377,0"/>
</svg></span>
                            <span class="title">Documentaci&#243;n</span>
                            <span class="summary">Obtener herramientas, tutoriales y ejemplos de c&#243;digo</span>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="column medium-3 medium-offset-1">
                <ul class="wa-iconList">
                    <li>
                        <a href="https://portal.azure.com/">
                            <span class="icon"><svg aria-hidden="true" role="presentation" data-slug-id="azure" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="azure:ab40b385-f958-420f-bfab-714be1677426-7797d565" x1="-960.606" y1="283.397" x2="-1032.511" y2="70.972" gradientTransform="matrix(1 0 0 -1 1075 318)" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#114a8b"/>
      <stop offset="1" stop-color="#0669bc"/>
    </linearGradient>
    <linearGradient id="azure:f40af90d-72eb-49b3-94b2-2510f1071722-07e5a8a0" x1="-938.144" y1="184.402" x2="-954.778" y2="178.778" gradientTransform="matrix(1 0 0 -1 1075 318)" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-opacity=".3"/>
      <stop offset=".071" stop-opacity=".2"/>
      <stop offset=".321" stop-opacity=".1"/>
      <stop offset=".623" stop-opacity=".05"/>
      <stop offset="1" stop-opacity="0"/>
    </linearGradient>
    <linearGradient id="azure:e382d742-7d51-4974-a256-24e182eef053-9ec3572f" x1="-947.292" y1="289.594" x2="-868.363" y2="79.308" gradientTransform="matrix(1 0 0 -1 1075 318)" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#3ccbf4"/>
      <stop offset="1" stop-color="#2892df"/>
    </linearGradient>
  </defs>
  <path d="M89.158 18.266h69.238L86.523 231.224a11.041 11.041 0 01-10.461 7.51H22.179a11.023 11.023 0 01-10.445-14.548l66.963-198.41a11.04 11.04 0 0110.461-7.51z" fill="url(#azure:ab40b385-f958-420f-bfab-714be1677426-7797d565)"/>
  <path d="M189.77 161.104H79.976a5.083 5.083 0 00-3.468 8.8l70.552 65.847a11.091 11.091 0 007.567 2.983h62.167z" fill="#0078d4"/>
  <path d="M89.158 18.266a10.95 10.95 0 00-10.483 7.654L11.817 224.006a11.01 11.01 0 0010.393 14.728h55.274a11.814 11.814 0 009.069-7.714l13.33-39.29 47.625 44.418a11.267 11.267 0 007.089 2.586h61.937l-27.166-77.63-79.19.018 48.47-142.856z" fill="url(#azure:f40af90d-72eb-49b3-94b2-2510f1071722-07e5a8a0)"/>
  <path d="M177.592 25.764a11.023 11.023 0 00-10.444-7.498H89.984a11.024 11.024 0 0110.445 7.498l66.967 198.421a11.024 11.024 0 01-10.445 14.549h77.164a11.024 11.024 0 0010.444-14.549z" fill="url(#azure:e382d742-7d51-4974-a256-24e182eef053-9ec3572f)"/>
</svg></span>
                            <span class="title">Azure Portal</span>
                            <span class="summary">Configurar y usar los servicios de Azure</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </section>

    <section class="section section--gray20" aria-label="Contacto">
        <div class="row column">
                <h2>¿Sigue teniendo problemas? <a href="/es-es/support/options/">Ponerse en contacto con nosotros</a></h2>
        </div>
    </section>

    <footer class="section section--gray100 section-size3 section-footer">
        <div class="row">
            <div class="column medium-9">
                <ul class="linkList linkList-horizontal">
                    <li><a href="https://feedback.azure.com/forums/34192--general-feedback">Comentarios</a></li>
                    <li><a href="https://www.microsoft.com/en-us/legal/intellectualproperty/Trademarks/">Marcas comerciales</a></li>
                    <li><a href="https://go.microsoft.com/fwlink/?LinkId=248681&clcid=0x40a">Privacidad y cookies</a></li>
                </ul>
            </div>
            <div class="column medium-3">
                <div class="footer-copyright pull-right">
                    <a aria-label="Microsoft" href="https://www.microsoft.com" class="logo-microsoft"><svg aria-hidden="true" role="presentation" data-slug-id="microsoft" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 244.052 47.146">
    <path d="M48.019,4.991v43.2h-7.5V14.33H40.4L26.99,48.191H22.02L8.283,14.33h-.09V48.191H1.263V4.991H12.018L24.43,37.015h.18l13.1-32.024Zm6.273,3.284A3.969,3.969,0,0,1,55.6,5.247a4.42,4.42,0,0,1,3.118-1.22,4.359,4.359,0,0,1,3.193,1.25,4.065,4.065,0,0,1,1.266,3,3.909,3.909,0,0,1-1.3,2.982,4.474,4.474,0,0,1-3.164,1.205,4.387,4.387,0,0,1-3.148-1.22A3.944,3.944,0,0,1,54.291,8.275Zm8.043,8.947V48.191h-7.29V17.222ZM84.448,42.889a10.068,10.068,0,0,0,3.584-.753,15.074,15.074,0,0,0,3.615-1.988v6.778a14.6,14.6,0,0,1-3.962,1.506,21.584,21.584,0,0,1-4.865.512A14.733,14.733,0,0,1,67.426,33.58a17.661,17.661,0,0,1,4.369-12.307q4.368-4.835,12.381-4.835a16.926,16.926,0,0,1,4.142.527,13.835,13.835,0,0,1,3.328,1.22v6.989A14.909,14.909,0,0,0,88.2,23.262a9.957,9.957,0,0,0-3.6-.678,9.137,9.137,0,0,0-6.959,2.8,10.548,10.548,0,0,0-2.651,7.561,10.065,10.065,0,0,0,2.546,7.321A9.191,9.191,0,0,0,84.448,42.889ZM112.4,16.71a9.239,9.239,0,0,1,1.567.12,6.544,6.544,0,0,1,1.175.3v7.38a6.363,6.363,0,0,0-1.672-.8,8.282,8.282,0,0,0-2.666-.376,5.659,5.659,0,0,0-4.534,2.259q-1.852,2.259-1.853,6.959V48.191H97.13V17.222h7.291V22.1h.12a8.547,8.547,0,0,1,3.013-3.962A8.173,8.173,0,0,1,112.4,16.71Zm3.136,16.448q0-7.682,4.338-12.171t12.05-4.489q7.26,0,11.343,4.323T147.352,32.5q0,7.532-4.338,11.99T131.2,48.944q-7.2,0-11.432-4.232T115.54,33.158Zm7.592-.241q0,4.851,2.2,7.411a7.843,7.843,0,0,0,6.3,2.56,7.341,7.341,0,0,0,6.055-2.56q2.079-2.561,2.079-7.592,0-5-2.154-7.547a7.48,7.48,0,0,0-6.04-2.545,7.638,7.638,0,0,0-6.221,2.666Q123.131,27.976,123.132,32.917ZM158.2,25.356a3.124,3.124,0,0,0,.994,2.455,17.011,17.011,0,0,0,4.4,2.244,14.908,14.908,0,0,1,6.13,3.932,8.152,8.152,0,0,1,1.762,5.287,8.5,8.5,0,0,1-3.359,7.019q-3.359,2.652-9.083,2.651a21.86,21.86,0,0,1-4.263-.467,18.991,18.991,0,0,1-3.962-1.19v-7.17a17.961,17.961,0,0,0,4.278,2.2,12.533,12.533,0,0,0,4.157.814,7.407,7.407,0,0,0,3.646-.693,2.477,2.477,0,0,0,1.174-2.32,3.221,3.221,0,0,0-1.22-2.546,18.084,18.084,0,0,0-4.625-2.4,14.284,14.284,0,0,1-5.724-3.8,8.314,8.314,0,0,1-1.687-5.363,8.474,8.474,0,0,1,3.329-6.884,13.283,13.283,0,0,1,8.631-2.7,20.89,20.89,0,0,1,3.645.361,16.121,16.121,0,0,1,3.374.934v6.929a15.571,15.571,0,0,0-3.374-1.657,11.257,11.257,0,0,0-3.826-.693,5.577,5.577,0,0,0-3.239.813A2.579,2.579,0,0,0,158.2,25.356Zm16.417,7.8q0-7.682,4.338-12.171T191,16.5q7.26,0,11.343,4.323T206.427,32.5q0,7.532-4.338,11.99t-11.81,4.458q-7.2,0-11.432-4.232T174.614,33.158Zm7.592-.241q0,4.851,2.2,7.411a7.843,7.843,0,0,0,6.3,2.56,7.341,7.341,0,0,0,6.055-2.56q2.079-2.561,2.079-7.592,0-5-2.154-7.547a7.48,7.48,0,0,0-6.04-2.545,7.638,7.638,0,0,0-6.221,2.666Q182.206,27.976,182.206,32.917Zm48.407-9.731H219.755v25h-7.38v-25h-5.182V17.222h5.182V12.914a10.716,10.716,0,0,1,3.178-8A11.146,11.146,0,0,1,223.7,1.8a18.088,18.088,0,0,1,2.35.136,9.322,9.322,0,0,1,1.808.406v6.3a7.546,7.546,0,0,0-1.266-.512,6.581,6.581,0,0,0-2.078-.3,4.4,4.4,0,0,0-3.525,1.431,6.316,6.316,0,0,0-1.235,4.232v3.736h10.858v-6.96l7.321-2.229v9.189h7.381v5.965h-7.381v14.49a6.108,6.108,0,0,0,1.039,4.037,4.148,4.148,0,0,0,3.269,1.175,4.873,4.873,0,0,0,1.522-.3,7.142,7.142,0,0,0,1.552-.723V47.89a8.575,8.575,0,0,1-2.3.723,15.726,15.726,0,0,1-3.178.331q-4.61,0-6.914-2.455t-2.3-7.4Z" transform="translate(-1.263 -1.797)" fill="#fff" />
</svg></a>
                    <span>&copy; 2021 Microsoft</span>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
